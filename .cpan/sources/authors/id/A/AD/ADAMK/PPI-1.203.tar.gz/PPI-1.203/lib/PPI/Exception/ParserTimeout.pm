package PPI::Exception::ParserTimeout;

use strict;
use base 'PPI::Exception';

use vars qw{$VERSION};
BEGIN {
	$VERSION = '1.203';
}

1;

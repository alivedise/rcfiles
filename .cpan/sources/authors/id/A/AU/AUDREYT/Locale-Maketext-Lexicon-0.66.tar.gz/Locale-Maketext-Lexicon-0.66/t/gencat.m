$ by Audrey Tang <cpan@audreyt.org>
$set 1 # $Id: //member/autrijus/Locale-Maketext-Lexicon/t/gencat.m#1 $
1 First string
2 Second \
str\
ing
$quote X
3 XThird stringX
4 XFourth X\
XstringX

package Foo::Plugin::Bar;

1;

package Scoped::Package;

1;
__END__
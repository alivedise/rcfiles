package IncSub;

sub check { print "***********\n" }

1

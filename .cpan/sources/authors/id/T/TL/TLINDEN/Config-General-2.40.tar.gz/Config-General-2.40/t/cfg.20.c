seen_cfg.20.c = true
last          = cfg.20.c
